tinyMCE.addI18n('en.latex_dlg',{
	title : 'Insert Latex code'
});
