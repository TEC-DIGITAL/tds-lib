tinyMCE.addI18n('en.example',{
	desc : 'Insert some Latex code'
});
